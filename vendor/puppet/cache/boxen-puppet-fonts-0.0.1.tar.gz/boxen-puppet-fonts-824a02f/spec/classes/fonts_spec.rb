require 'spec_helper'

describe 'fonts' do
  it should do
    should include_class('fonts')
    should include_class('fonts::adobe')
  end
end
