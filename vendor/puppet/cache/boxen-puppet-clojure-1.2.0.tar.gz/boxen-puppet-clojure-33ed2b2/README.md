# Clojure Puppet Module for Boxen

Install the [Clojure](http://clojure.org) programming language.

## Usage

```puppet
include clojure
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `java`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
