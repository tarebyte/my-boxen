# 0MQ Puppet Module for Boxen

## Usage

```puppet
include zeromq
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib

## Developing

Write code.

Run `script/cibuild`.
