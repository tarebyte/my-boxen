# 1Password Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-onepassword.png?branch=master)](https://travis-ci.org/boxen/puppet-onepassword)

## Usage

```puppet
include onepassword
```

## Required Puppet Modules

* boxen
* stdlib
