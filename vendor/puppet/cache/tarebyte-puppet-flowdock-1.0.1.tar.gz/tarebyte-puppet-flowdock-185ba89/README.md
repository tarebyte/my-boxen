# Flowdock Puppet Module for Boxen [![Build Status](https://travis-ci.org/geetarista/puppet-flowdock.svg?branch=master)](https://travis-ci.org/geetarista/puppet-flowdock)

Installs the Flowdock Mac app.

## Usage

```puppet
include flowdock
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
