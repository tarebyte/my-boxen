# Boxen 

[![Build Status](https://travis-ci.org/boxen/puppet-boxen.png?branch=master)](https://travis-ci.org/boxen/puppet-boxen)

The Boxen puppet module for... Boxen.

# Required Modules for Boxen

Fundamental modules and types used by all of Boxen.

## Usage

```puppet
# We owe you examples. Sorry.
```

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
