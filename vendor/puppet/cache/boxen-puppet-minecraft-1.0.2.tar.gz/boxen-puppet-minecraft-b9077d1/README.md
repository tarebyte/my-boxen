# Minecraft Puppet Module for Boxen

## Usage

```puppet
include minecraft
```

## Required Puppet Modules

* boxen
* stdlib
